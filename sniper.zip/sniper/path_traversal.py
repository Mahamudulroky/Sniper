from display import Display
"""
class Display:
    def output(out):#accpeting full_path
        return print(out)
"""
import logging
from fuzz import PathTraversal
logging.getLogger("urllib3").setLevel(logging.ERROR)
logging.getLogger("requests").setLevel(logging.ERROR)
fuzzer=PathTraversal()
fuzzer._base_url="https://www.google.com"
fuzzer.start()

