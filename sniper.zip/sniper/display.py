class Display:
    def output(out):#accpeting full_path
        return print(out)
